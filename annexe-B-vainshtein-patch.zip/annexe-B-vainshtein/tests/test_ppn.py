"""
Tests d'invariants pour scripts/ppn_check.py - validation déterministe.

Ces tests vérifient la COHÉRENCE INTERNE des formules (B.4.1)-(B.5.4).
Ils ne valident NI la valeur de beta (non sourcée), NI le choix de Lambda.
Un script qui passe ces tests peut produire un chiffre faux si ses
paramètres d'entrée le sont.

Usage :  python3 tests/test_ppn.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
import ppn_check as pc  # noqa: E402

HBARC = 1.973269804e-16  # GeV.m
HBAR_GEV_S = 6.582119569e-25  # GeV.s
MPC_M = 3.0856775815e22  # m par Mpc
M_PL = 2.435e18  # GeV
TOL = 1e-9


def Y_exact(r, alpha, beta, M, Lam):
    """Solution exacte (B.4.2), branche régulière à l'infini."""
    rV3 = alpha * beta * M / (4.0 * np.pi * Lam ** 3)
    x = 4.0 * rV3 / r ** 3
    # Forme stable : sqrt(1+x)-1 s'annule en float64 pour x < 1e-16.
    return (Lam ** 3 / (2.0 * alpha)) * x / (np.sqrt(1.0 + x) + 1.0)


def residu_B41(Y, r, alpha, beta, M, Lam):
    """Résidu de la première intégrale : doit être nul."""
    return Y + (alpha / Lam ** 3) * Y ** 2 - beta * M / (4.0 * np.pi * r ** 3)


def r_V(alpha, beta, M, Lam):
    return (alpha * beta * M / (4.0 * np.pi * Lam ** 3)) ** (1.0 / 3.0)


def lambda_cosmo(h0_km_s_mpc=70.0):
    """Lambda recalculé depuis Lambda^3 = M_Pl H0^2, jamais recopié."""
    h0_gev = (h0_km_s_mpc * 1.0e3 / MPC_M) * HBAR_GEV_S
    return (M_PL * h0_gev ** 2) ** (1.0 / 3.0)


# Jeu de paramètres arbitraire : les tests portent sur la STRUCTURE,
# pas sur des valeurs physiques particulières.
A, B, M, L = 2.0, 1.0e-11, 1.1182e57, 5.0e-30


def t1_solution_verifie_equation():
    """(B.4.2) doit annuler (B.4.1) sur plusieurs décades."""
    rv = r_V(A, B, M, L)
    for r in rv * np.logspace(-4, 4, 40):
        res = residu_B41(Y_exact(r, A, B, M, L), r, A, B, M, L)
        ech = B * M / (4.0 * np.pi * r ** 3)
        assert abs(res) / ech < TOL, f"résidu {res / ech:.2e} à r/r_V={r / rv:.1e}"


def t2_limite_alpha_nul():
    """
    alpha -> 0 doit redonner le régime linéaire Y = beta M / 4 pi r^3.

    Le rayon d'évaluation est FIXE (r_V pris à alpha = 1). L'ancienne
    version évaluait à 1e6 * r_V(alpha), un point qui suit alpha : l'écart
    y valait ~1e-16 pour tout alpha et le test passait même à alpha=1e12.
    Il testait la limite grand-r, pas la limite alpha -> 0.

    Ici Y/Y_lin = 2 / (sqrt(1+4 alpha) + 1), donc l'écart vaut ~alpha aux
    petits alpha et reste O(1) à alpha = 1 : le test a des dents.
    """
    r = r_V(1.0, B, M, L)
    lin = B * M / (4.0 * np.pi * r ** 3)

    for a in [1e-3, 1e-6, 1e-9, 1e-12]:
        ecart = abs(Y_exact(r, a, B, M, L) - lin) / lin
        assert ecart < 3.0 * a, f"alpha={a:.0e} : écart {ecart:.2e} non O(alpha)"

    # Contrôle négatif : le test doit ÉCHOUER à alpha = O(1).
    ecart_un = abs(Y_exact(r, 1.0, B, M, L) - lin) / lin
    assert ecart_un > 0.3, f"test sans pouvoir discriminant (écart {ecart_un:.2e})"


def t3_transition_a_rV():
    """
    À r = r_V, le rapport terme cubique / terme linéaire de (B.4.1) vaut
    (sqrt(5) - 1) / 2 = 1/phi, et non 1.

    Les deux termes ne sont donc PAS égaux à r_V : c'est la convention de
    matching retenue au point 6 qui place la transition ici, à un facteur
    0.618 près. Y(r_V) = Lambda^3 (sqrt(5) - 1) / (2 alpha).
    """
    rv = r_V(A, B, M, L)
    Y = Y_exact(rv, A, B, M, L)
    lineaire, cubique = Y, (A / L ** 3) * Y ** 2
    rapport = cubique / lineaire
    attendu = (np.sqrt(5.0) - 1.0) / 2.0
    assert abs(rapport - attendu) < TOL, f"rapport {rapport:.6f}"


def t4_asymptotiques():
    """Préfacteur 1 des deux côtés de (B.4.3)."""
    rv = r_V(A, B, M, L)
    # Extérieur : phi' -> beta M / 4 pi r^2
    r = 1e4 * rv
    ext = (r * Y_exact(r, A, B, M, L)) / (B * M / (4.0 * np.pi * r ** 2))
    assert abs(ext - 1.0) < 1e-3, f"extérieur : {ext:.6f}"
    # Intérieur : phi' -> beta M / 4 pi r^2 (r/r_V)^{3/2}
    r = 1e-6 * rv
    ref = (B * M / (4.0 * np.pi * r ** 2)) * (r / rv) ** 1.5
    inte = (r * Y_exact(r, A, B, M, L)) / ref
    assert abs(inte - 1.0) < 1e-3, f"intérieur : {inte:.6f}"


def t5_homogeneite():
    """Invariance d'échelle : (beta,M,Lambda) -> (k beta, M, k^{1/3} Lambda)."""
    rv0 = r_V(A, B, M, L)
    for k in [1e-6, 1e3, 1e9]:
        rv = r_V(A, k * B, M, k ** (1.0 / 3.0) * L)
        assert abs(rv - rv0) / rv0 < TOL, f"k={k:.0e}"


def t6_lambda_cosmologique():
    """Lambda recalculé, pas recopié. Garde-fou contre l'erreur de 11 ordres."""
    lam = lambda_cosmo()
    assert 1.5e-22 < lam < 2.0e-22, f"Lambda = {lam:.3e} GeV hors plage"
    faux = 5.13e-34
    assert lam / faux > 1e10, "la valeur erronée n'est plus écartée"


def t7_loi_de_puissance_en_beta():
    """
    En régime écranté, |gamma - 1| = C beta^{3/2}.

    Justifie l'inversion analytique de beta_max_cassini() : pas de
    résolution numérique nécessaire, mais l'exposant doit être vérifié.
    """
    b0 = 1e-17
    d0, _, _ = pc.ecart_ppn(b0)
    for k in [10.0, 100.0, 1e4]:
        d, _, _ = pc.ecart_ppn(k * b0)
        assert abs(d / d0 - k ** 1.5) / k ** 1.5 < 1e-9, f"k={k:.0e}"


def t8_garde_fou_epsilon():
    """
    Le drapeau de validité doit tomber exactement à epsilon = 1,
    c'est-à-dire beta = 1/M_*. Au-delà, (B.5.4) est hors domaine et
    |gamma - 1| = 5.9e14 (ancienne sortie du script) n'a aucun sens.
    """
    _, _, valide_petit = pc.ecart_ppn(0.5 / M_PL)
    _, _, valide_grand = pc.ecart_ppn(2.0 / M_PL)
    assert valide_petit, "epsilon < 1 marqué invalide"
    assert not valide_grand, "epsilon > 1 marqué valide"
    _, _, valide_ref = pc.ecart_ppn(1.0e-11)
    assert not valide_ref, "beta = 1e-11 (epsilon = 5.9e14) doit être rejeté"


def t9_seuil_cassini_coherent():
    """Le seuil renvoyé doit saturer la borne, et 1/M_Pl doit passer."""
    b_max = pc.beta_max_cassini()
    d, _, _ = pc.ecart_ppn(b_max)
    assert abs(d / pc.BOUND_CASSINI - 1.0) < 1e-6, f"|gamma-1|(b_max) = {d:.3e}"
    d_grav, _, valide = pc.ecart_ppn(1.0 / M_PL)
    assert valide and d_grav < pc.BOUND_CASSINI, "1/M_Pl devrait passer Cassini"


if __name__ == "__main__":
    tests = [
        ("solution vérifie (B.4.1)", t1_solution_verifie_equation),
        ("limite alpha -> 0 (corrigé)", t2_limite_alpha_nul),
        ("transition à r_V", t3_transition_a_rV),
        ("asymptotiques (B.4.3)", t4_asymptotiques),
        ("homogénéité dimensionnelle", t5_homogeneite),
        ("Lambda recalculé", t6_lambda_cosmologique),
        ("loi de puissance beta^{3/2}", t7_loi_de_puissance_en_beta),
        ("garde-fou epsilon < 1", t8_garde_fou_epsilon),
        ("seuil Cassini cohérent", t9_seuil_cassini_coherent),
    ]
    echecs = 0
    for nom, f in tests:
        try:
            f()
            print(f"  OK    {nom}")
        except AssertionError as e:
            print(f"  ECHEC {nom} : {e}")
            echecs += 1
    print(f"\n{len(tests) - echecs}/{len(tests)} tests passés")
    print("Rappel : cohérence interne uniquement - beta reste non sourcé.")
    sys.exit(1 if echecs else 0)
