"""
Contrôle numérique de l'annexe B (Propositions B.4-B.5).

ATTENTION
---------
Outil de reproduction numérique, pas de validation physique.

Aucune valeur de Lambda n'est codée en dur : elle est recalculée depuis
M_Pl et H0, précisément pour qu'une erreur de dérivation ne puisse pas se
propager silencieusement (une valeur antérieure de 5.13e-34 GeV,
présentée comme issue de Lambda^3 = M_Pl H0^2, s'écartait de 11 ordres de
grandeur du résultat correct).

Le paramètre ouvert est beta. Ce script ne se contente plus d'une valeur
unique : il balaie beta et calcule le seuil imposé par Cassini, de sorte
que la conclusion affichée ne dépende pas d'un chiffre bouché-trou.

Usage :  python3 scripts/ppn_check.py
"""

import numpy as np

# ------------------------------------------------------------------
# Constantes fondamentales et conversions (hbar = c = 1)
# ------------------------------------------------------------------
HBARC = 1.973269804e-16  # GeV.m
HBAR_GEV_S = 6.582119569e-25  # GeV.s
MPC_M = 3.0856775815e22  # m par Mpc
PC_M = 3.0856775815e16  # m par pc
AU_M = 1.495978707e11  # m
GEV_TO_M = HBARC  # 1 GeV^-1 -> m
M_TO_GEV_MASS = 7.571e53  # masse géométrisée (m) -> GeV

# ------------------------------------------------------------------
# Paramètres du modèle
# ------------------------------------------------------------------
ALPHA = 2.0  # = 2 kappa, coefficient galiléon   (à confirmer, B.2.x)
M_PL = 2.435e18  # GeV, masse de Planck réduite
H0_KM_S_MPC = 70.0  # km/s/Mpc

BETA_REF = 1.0e-11  # GeV^-1, valeur historique du script  (NON SOURCÉE)
BETA_GRAV = 1.0 / M_PL  # GeV^-1, couplage de force gravitationnelle

# ------------------------------------------------------------------
# Lambda recalculé depuis Lambda^3 = M_Pl H0^2  (jamais recopié)
# ------------------------------------------------------------------
H0_SI = H0_KM_S_MPC * 1.0e3 / MPC_M  # s^-1
H0_GEV = H0_SI * HBAR_GEV_S  # GeV
LAMBDA_GEV = (M_PL * H0_GEV ** 2) ** (1.0 / 3.0)  # GeV
LAMBDA_M_INV = LAMBDA_GEV / HBARC  # m^-1

# ------------------------------------------------------------------
# Données astrophysiques et observationnelles
# ------------------------------------------------------------------
M_SUN_GEOM_M = 1.477e3  # m (masse géométrisée)
M_SUN_GEV = M_SUN_GEOM_M * M_TO_GEV_MASS  # GeV
BOUND_CASSINI = 2.3e-5
R_UNIVERS_OBSERVABLE_M = 4.4e26  # rayon comobile (~14.3 Gpc)


# ------------------------------------------------------------------
# Moteur de calcul
# ------------------------------------------------------------------
def rayon_vainshtein_m(beta, alpha=ALPHA, masse_gev=M_SUN_GEV, lam=LAMBDA_GEV):
    """(B.4.2) : r_V^3 = alpha beta M / (4 pi Lambda^3), rendu en mètres."""
    r_gev_inv = (alpha * beta * masse_gev / (4.0 * np.pi * lam ** 3)) ** (1.0 / 3.0)
    return r_gev_inv * GEV_TO_M


def epsilon(beta, m_star=M_PL):
    """epsilon = beta^2 M_*^2. Paramètre PERTURBATIF : n'a de sens que < 1."""
    return (beta * m_star) ** 2


# Tolérance sur le bord epsilon = 1 : beta = 1/M_* y tombe exactement, et
# l'arrondi float64 de (beta * M_*)^2 peut le placer d'un côté ou de l'autre.
TOL_EPS = 1e-9


def ecart_ppn(beta, r_m=AU_M, **kw):
    """
    (B.5.4). Renvoie (|gamma - 1|, regime, valide).

    `valide` est False dès que epsilon > 1 : le développement dont
    (B.5.4) est le premier terme suppose epsilon petit, et gamma - 1 est
    de toute façon borné. Au-delà, le nombre affiché n'a pas de sens.
    Le cas marginal epsilon = 1 (beta = 1/M_*) est accepté.
    """
    eps = epsilon(beta)
    valide = eps <= 1.0 + TOL_EPS
    r_v = rayon_vainshtein_m(beta, **kw)
    if r_m < r_v:
        return eps * (r_m / r_v) ** 1.5, "écranté (r << r_V)", valide
    return eps, "NON écranté (r >~ r_V)", valide


def beta_max_cassini(r_m=AU_M, bound=BOUND_CASSINI):
    """
    Seuil analytique sur beta.

    En régime écranté, r_V ~ beta^{1/3} donc (r/r_V)^{3/2} ~ beta^{-1/2}
    et |gamma - 1| = C beta^{3/2}. Le seuil s'inverse exactement, sans
    résolution numérique.
    """
    dg_ref, _, _ = ecart_ppn(BETA_REF, r_m)
    c = dg_ref / BETA_REF ** 1.5
    return (bound / c) ** (2.0 / 3.0)


# ------------------------------------------------------------------
# Rapport
# ------------------------------------------------------------------
def main():
    print("=" * 78)
    print("RAPPORT DE CONTROLE NUMERIQUE - ANNEXE B")
    print("=" * 78)
    print(f"H0                  : {H0_KM_S_MPC:.1f} km/s/Mpc = {H0_GEV:.3e} GeV")
    print(f"Lambda (recalculé)  : {LAMBDA_GEV:.3e} GeV = {LAMBDA_M_INV:.3e} m^-1")
    print(f"  longueur 1/Lambda : {HBARC / LAMBDA_GEV:.3e} m  (échelle Lambda_3 attendue)")
    print(f"alpha               : {ALPHA}   (à confirmer, B.2.x)")
    print("-" * 78)

    b_max = beta_max_cassini()
    print("BALAYAGE EN beta  (Soleil, r = 1 UA)")
    print(f"{'beta [GeV^-1]':>14} {'beta.M_Pl':>11} {'r_V':>12} {'epsilon':>11}"
          f" {'|gamma-1|':>11}  verdict")
    print("-" * 78)

    grille = [1.0e-11, 1.0e-12, 1.0e-13, b_max, 1.0e-15, 1.0e-17, BETA_GRAV]
    for b in sorted(set(grille), reverse=True):
        r_v = rayon_vainshtein_m(b)
        dg, _, valide = ecart_ppn(b)
        if not valide:
            verdict = "epsilon>1 : NON EXPLOITABLE"
        elif dg >= BOUND_CASSINI:
            verdict = "EXCLU par Cassini"
        elif epsilon(b) > 0.99:
            verdict = "compatible (epsilon marginal)"
        else:
            verdict = "compatible Cassini"
        etiq = " <- 1/M_Pl" if abs(b - BETA_GRAV) / BETA_GRAV < 1e-9 else ""
        print(f"{b:>14.3e} {b * M_PL:>11.2e} {r_v / PC_M:>9.3e} pc"
              f" {epsilon(b):>11.2e} {dg:>11.3e}  {verdict}{etiq}")

    print("-" * 78)
    print(f"Seuil Cassini (formule B.5.4) : beta <= {b_max:.3e} GeV^-1"
          f"  (beta.M_Pl <= {b_max * M_PL:.2e})")
    print(f"Seuil de validité perturbative : beta <= {1.0 / M_PL:.3e} GeV^-1"
          f"  (epsilon < 1)")
    print("  -> c'est epsilon < 1, et non Cassini, qui contraint le plus beta.")
    print("-" * 78)

    r_v_grav = rayon_vainshtein_m(BETA_GRAV)
    dg_grav, regime, _ = ecart_ppn(BETA_GRAV)
    print("CAS DE RÉFÉRENCE : couplage de force gravitationnelle (beta = 1/M_Pl)")
    print(f"  r_V (Soleil)      : {r_v_grav:.3e} m = {r_v_grav / PC_M:.1f} pc")
    print(f"  régime à 1 UA     : {regime}")
    print(f"  |gamma - 1|       : {dg_grav:.3e}   vs Cassini {BOUND_CASSINI:.1e}")
    print(f"  marge             : {BOUND_CASSINI / dg_grav:.1e}")

    if rayon_vainshtein_m(BETA_REF) / R_UNIVERS_OBSERVABLE_M > 100:
        print("!! ALERTE : r_V dépasse 100x le rayon de l'univers observable.")

    print("-" * 78)
    print("AVERTISSEMENT SCIENTIFIQUE")
    print("beta n'est toujours pas dérivé du manuscrit (B.1.x : beta = 2 xi psi_0")
    print("/ M_*^2, psi_0 manquant). Le tableau ci-dessus délimite l'espace des")
    print("valeurs admissibles ; il ne sélectionne pas la bonne. La valeur de")
    print("Lambda retenue découle de Lambda^3 = M_Pl H0^2 et reste à réconcilier")
    print("avec Lambda = 1e-3 GeV figurant dans la table du manuscrit.")
    print("=" * 78)


if __name__ == "__main__":
    main()
