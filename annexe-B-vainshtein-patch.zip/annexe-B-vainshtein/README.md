# Annexe B — Mécanisme de Vainshtein

Vérification numérique de l'annexe B (Propositions B.4–B.5) du manuscrit
Elasto-Gravity : profil radial du champ scalaire, rayon de Vainshtein, et
écart post-newtonien `|γ − 1|` confronté à la borne Cassini.

## ⚠️ Statut : travail en cours — résultats non validés

Ce dépôt contient un **outil de reproduction numérique**, pas une validation
physique. Le paramètre `β` n'est pas encore dérivé du manuscrit. Le script
ne prétend donc plus trancher : il **balaie `β`** et affiche l'espace des
valeurs admissibles.

| Paramètre | Valeur utilisée | Statut | Source |
|---|---|---|---|
| `α = 2κ` | 2.0 | à confirmer | B.2.x (non tracé) |
| `Λ` | 1.758×10⁻²² GeV | dérivation vérifiée | Λ³ = M_Pl H₀², recalculé dans le script |
| `β` | **balayé** | **NON SOURCÉ** | B.1.x (`β ≡ 2ξψ₀/M_*²`, ψ₀ manquant) |
| `M_*` | M_Pl = 2.435×10¹⁸ GeV | approximation | suppose ξψ₀² ≪ M_Pl² |

Contrôle de cohérence : `1/Λ = 1.12×10⁶ m ≈ 1120 km`, l'échelle Λ₃ attendue
pour un galiléon cubique avec Λ³ = M_Pl H₀².

## Deux contraintes sur `β`, pas une

L'ancienne version concluait « exclu par Cassini » à partir de la seule
valeur `β = 10⁻¹¹ GeV⁻¹`. Cette valeur correspond à `β·M_Pl = 2.4×10⁷`,
soit un couplage scalaire **24 millions de fois plus fort que la gravité** :
elle est écartée bien avant tout test de système solaire.

| β (GeV⁻¹) | β·M_Pl | ε ≡ β²M_*² | r_V (Soleil) | \|γ − 1\| à 1 UA | verdict |
|---|---|---|---|---|---|
| 10⁻¹¹ (ancienne valeur) | 2.4×10⁷ | 5.9×10¹⁴ | 44 kpc | 0.68 | ε > 1 : **hors domaine** |
| 1.04×10⁻¹⁴ | 2.5×10⁴ | 6.4×10⁸ | 4.5 kpc | 2.3×10⁻⁵ | seuil Cassini formel |
| **1/M_Pl = 4.11×10⁻¹⁹** | **1** | **1** | **152 pc** | **5.7×10⁻¹²** | **compatible, marge 4×10⁶** |

Deux seuils distincts, et ce n'est pas le plus évident qui mord :

- **Cassini** (via B.5.4) : `β ≲ 1.04×10⁻¹⁴ GeV⁻¹`. En régime écranté
  `r_V ∝ β^{1/3}`, donc `|γ − 1| = C·β^{3/2}` et le seuil s'inverse
  analytiquement — pas de résolution numérique (test `t7`).
- **Validité perturbative** : `ε ≡ β²M_*² < 1`, soit `β ≲ 1/M_* = 4.1×10⁻¹⁹ GeV⁻¹`.
  **Quatre ordres et demi plus contraignant.** `|γ − 1| = O(ε)·(r/r_V)^{3/2}`
  est le premier terme d'un développement en ε ; à ε = 5.9×10¹⁴ le nombre
  affiché n'a aucun sens, d'autant que `γ − 1` est borné. Le script refuse
  désormais d'en tirer un verdict (garde-fou testé par `t8`).

À couplage de force gravitationnelle, `r_V = 152 pc` — la valeur standard du
rayon de Vainshtein solaire en galiléon cubique — et le modèle passe Cassini
avec six ordres de marge. **Le résultat « exclu » documentait le paramètre
bouché-trou, pas le modèle.**

### Statut des valeurs de Λ

Trois valeurs circulent. Le script ne code aucune d'elles en dur : il
recalcule Λ depuis M_Pl et H₀ à chaque exécution.

| Valeur | Origine | Statut |
|---|---|---|
| 1.758×10⁻²² GeV | recalcul de Λ³ = M_Pl H₀² | **dérivation vérifiée** |
| 5.13×10⁻³⁴ GeV | script antérieur | incompatible — corrigé, verrouillé par `t6` |
| 10⁻³ GeV | table de `Elasto_Gravity_Jd.tex` | à interpréter (même paramètre ?) |

**À vérifier en priorité.** Établir si le Λ de la table désigne bien le même
paramètre que celui du terme cubique de (B.3.6) — même normalisation, même
dimension, après d'éventuelles redéfinitions de champ. L'action des fichiers
`.tex` fait apparaître Λ dans `-(1/Λ³)(∂ψ)²□ψ`, au même endroit structurel
que (B.3.6), ce qui est un indice mais non une preuve : une constante
absorbée reste possible et devrait alors être documentée explicitement.

## Contenu

```
scripts/ppn_check.py       # moteur de calcul (unités naturelles homogènes)
tests/test_ppn.py          # 9 tests d'invariants
examples/jupiter_orbit.py  # démo d'intégration orbitale — SANS RAPPORT avec l'annexe B
```

## Formules implémentées

Rayon de Vainshtein, première intégrale de l'équation maîtresse (B.4.2) :

```
r_V³ = α β M / (4π Λ³)
```

Écart post-newtonien en régime écranté (B.5.4) :

```
|γ − 1| = O(ε) · (r / r_V)^{3/2}     avec  ε ≡ β² M_*²,  valable pour ε ≲ 1
```

L'exposant 3/2 provient de la racine du discriminant de (B.4.1) ; il est
indépendant de la normalisation du terme cubique. Seul le préfacteur
numérique de `r_V` dépend de la convention retenue pour α.

## Utilisation

```bash
python3 scripts/ppn_check.py   # rapport + balayage en β
python3 tests/test_ppn.py      # 9/9 attendus
```

## Portée des tests

Les tests vérifient la **cohérence interne** des formules (B.4.1)–(B.5.4) :
résidu de la première intégrale sur 8 décades, limite α → 0, transition à
`r_V`, préfacteurs asymptotiques, invariance d'échelle, recalcul de Λ, loi
de puissance en β^{3/2}, garde-fou sur ε, saturation du seuil Cassini.

Ils ne valident **ni** la valeur de β, **ni** le choix de Λ. Un script qui
passe ces tests peut produire un chiffre faux si ses entrées le sont.

## Prochaines étapes

- [ ] **Sourcer `β` depuis B.1.x** (`β ≡ 2ξψ₀/M_*²` — la valeur de ψ₀ manque).
      Question à trancher : le modèle prédit-il `β ~ 1/M_Pl` ? Si oui, l'annexe B
      passe Cassini et le paragraphe de conclusion est à réécrire.
- [ ] Établir si le Λ de la table du manuscrit est le même paramètre que celui de (B.3.6)
- [ ] Confirmer `α = 2κ` depuis la construction galiléonne (B.2.x)
- [ ] Fixer le cadre (Jordan ou Einstein) des équations linéarisées (B.5.1)
- [ ] Justifier `M_* ≈ M_Pl` ou propager `M_* ≠ M_Pl` dans ε

## Licence

MIT
