"""
Démonstration d'intégration orbitale (Euler-Cromer) - SANS RAPPORT avec l'annexe B.

Conservé ici à titre d'exemple pédagogique. Deux correctifs par rapport à
la version précédente :

1. Le diagnostic d'énergie mélangeait l'ancienne distance et la nouvelle
   vitesse (décalage d'un demi-pas), ce qui gonflait artificiellement la
   dérive affichée. L'énergie est maintenant évaluée au même instant.
2. L'orbite simulée est CIRCULAIRE : v = 13.07 km/s au demi-grand axe est
   à 0.1 % de la vitesse circulaire (13.058 km/s). L'orbite réelle de
   Jupiter a e = 0.0489. Le titre le dit désormais.

Usage :  python3 examples/jupiter_orbit.py [--save fichier.png]
"""

import argparse

import numpy as np

# ==========================================
# CONSTANTES PHYSIQUES ET PARAMÈTRES
# ==========================================
G = 6.67430e-11  # m^3 kg^-1 s^-2
M_SOLEIL = 1.989e30  # kg
AU = 1.495978707e11  # m

R_JUPITER = 778.5e9  # demi-grand axe (m)
V_JUPITER = 13.07e3  # vitesse orbitale moyenne (m/s)
DT = 86400  # 1 jour


def simuler(dt=DT):
    """Euler-Cromer (semi-implicite) : erreur d'énergie bornée, non séculaire."""
    t_orbital = 2 * np.pi * np.sqrt(R_JUPITER ** 3 / (G * M_SOLEIL))
    steps = int(np.ceil(t_orbital / dt))

    position = np.array([R_JUPITER, 0.0], dtype=float)
    vitesse = np.array([0.0, V_JUPITER], dtype=float)

    traj = [position.copy()]
    energies = []

    for _ in range(steps):
        acceleration = -(G * M_SOLEIL / np.linalg.norm(position) ** 3) * position
        vitesse += acceleration * dt
        position += vitesse * dt
        traj.append(position.copy())
        # Énergie évaluée au MÊME instant que la vitesse (correctif 1).
        d = np.linalg.norm(position)
        energies.append(0.5 * np.dot(vitesse, vitesse) - G * M_SOLEIL / d)

    return np.array(traj), np.array(energies), steps, t_orbital


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--save", metavar="PNG", help="écrire la figure au lieu de l'afficher")
    args = ap.parse_args()

    import matplotlib
    if args.save:
        matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.style.use("dark_background")

    traj, energies, steps, t_orbital = simuler()
    derive = (energies[-1] - energies[0]) / abs(energies[0])
    fermeture = np.linalg.norm(traj[-1] - traj[0]) / R_JUPITER

    print(f"Période (Kepler)     : {t_orbital / 86400:.1f} j = {t_orbital / 3.156e7:.3f} ans")
    print(f"Vitesse circulaire   : {np.sqrt(G * M_SOLEIL / R_JUPITER):.1f} m/s"
          f"  (utilisée : {V_JUPITER:.1f})")
    print(f"Dérive d'énergie     : {derive:.3e} sur une orbite")
    print(f"Erreur de fermeture  : {100 * fermeture:.2f} % du rayon")

    x, y = traj[:, 0] / AU, traj[:, 1] / AU
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

    ax1.plot(x, y, color="orange", linestyle="--", label="Orbite (approx. circulaire)")
    ax1.plot(0, 0, "o", markersize=12, color="yellow", label="Soleil")
    ax1.plot(x[0], y[0], "o", markersize=5, color="green", label="Départ (t=0)")
    ax1.plot(x[-1], y[-1], "x", markersize=7, color="cyan", label="Arrivée (1 orbite)")
    ax1.set_title(f"Orbite circulaire au demi-grand axe de Jupiter ({steps} j)", fontsize=11)
    ax1.set_xlabel("X (UA)")
    ax1.set_ylabel("Y (UA)")
    ax1.grid(True, alpha=0.3)
    ax1.legend(fontsize=9)
    ax1.axis("equal")

    ax2.plot(np.arange(steps), (energies - energies[0]) / abs(energies[0]), color="magenta")
    ax2.set_title("Dérive relative de l'énergie mécanique", fontsize=11)
    ax2.set_xlabel("Temps (jours)")
    ax2.set_ylabel(r"$\Delta E / E_0$")
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    if args.save:
        plt.savefig(args.save, dpi=120)
        print(f"Figure écrite : {args.save}")
    else:
        plt.show()


if __name__ == "__main__":
    main()
