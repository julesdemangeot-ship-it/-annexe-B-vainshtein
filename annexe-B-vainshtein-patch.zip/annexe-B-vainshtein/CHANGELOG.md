# Correctifs

## Structure

- `Ppn Check` supprimé — doublon octet-pour-octet de `ppn_check.py`.
- `README2` supprimé — doublon octet-pour-octet de `README.md`.
- `Test ppn` → `tests/test_ppn.py`. L'ancien nom (espace, sans extension)
  rendait injouable le `python3 test_ppn.py` annoncé dans sa propre docstring.
- `ppn_check.py` → `scripts/ppn_check.py`, l'arborescence que le README
  décrivait déjà mais qui n'existait pas.
- `jupiter_simulation.py` → `examples/jupiter_orbit.py`, isolé du reste :
  sans rapport avec l'annexe B.

## Fond

**Garde-fou sur ε.** `|γ − 1| = O(ε)(r/r_V)^{3/2}` est le premier terme d'un
développement en ε ≡ β²M_*². À β = 10⁻¹¹ GeV⁻¹, ε = 5.9×10¹⁴ : le script
affichait `|γ − 1| = 0.68` et concluait « exclu », alors que la formule était
hors domaine. Pire, la branche non écrantée aurait affiché `|γ − 1| = 5.9×10¹⁴`,
une quantité pourtant bornée. `ecart_ppn()` renvoie désormais un drapeau de
validité et le rapport refuse de trancher quand ε > 1.

**Balayage en β au lieu d'une valeur unique.** Le verdict ne dépend plus d'un
chiffre non sourcé. `beta_max_cassini()` inverse analytiquement
`|γ − 1| = C·β^{3/2}` (exposant vérifié par `t7`) et donne
`β ≤ 1.042×10⁻¹⁴ GeV⁻¹`. Le README annonçait `β ≲ 10⁻²³` : neuf ordres trop
strict.

**Origine du `β ≲ 10⁻²³` retrouvée.** Quatre reconstructions testées ; une
seule reproduit les deux chiffres de l'ancienne parenthèse
(`β ≲ 10⁻²³ GeV⁻¹`, `β·M_Pl ≲ 10⁻⁵`) :

| Hypothèse | β | β·M_Pl |
|---|---|---|
| **`\|γ − 1\| = β·M_Pl`** | **9.45×10⁻²⁴** | **2.30×10⁻⁵** |
| `\|γ − 1\| = ε = (β·M_Pl)²` | 1.97×10⁻²¹ | 4.8×10⁻³ |
| formule complète, ancien Λ = 5.13×10⁻³⁴ | 3.6×10⁻³ | 8.7×10¹⁵ |
| formule complète (B.5.4), Λ corrigé | 1.04×10⁻¹⁴ | 2.5×10⁴ |

La première donne β·M_Pl = 2.30×10⁻⁵, c'est-à-dire **la borne Cassini
elle-même**, arrondie en « ≲ 10⁻⁵ » dans l'ancien texte. Le calcul posait
donc `β·M_Pl = |γ − 1|_max` directement, omettant à la fois le carré de
`ε = β²M_*²` et le facteur d'écrantage `(r/r_V)^{3/2}`.

Ce n'est donc ni une convention alternative de Λ, ni une autre définition de
β : c'est une erreur identifiée. Elle est consignée ici plutôt que dans le
README, la valeur n'ayant plus de statut de résultat.

**Cas de référence ajouté.** À β = 1/M_Pl (couplage de force gravitationnelle),
r_V = 152 pc — la valeur standard pour le Soleil en galiléon cubique, ce qui
est en soi un contrôle de la formule (B.4.2) — et `|γ − 1| = 5.7×10⁻¹²`,
compatible Cassini avec six ordres de marge.

## Tests

**`t2` réparé.** Il évaluait à `r = 10⁶·r_V(α)`, un point qui suit α :
l'écart y valait ~10⁻¹⁶ **pour tout α**. Vérifié — il passait à α = 10¹². Il
testait la limite grand-r, pas la limite α → 0. Il évalue désormais à un rayon
fixe, où `Y/Y_lin = 2/(√(1+4α)+1)` : l'écart est O(α) aux petits α. Un contrôle
négatif assure qu'il échoue bien à α = 1 (écart 38 %), c'est-à-dire qu'il
discrimine réellement.

**`t3` : docstring corrigée.** Elle affirmait que les deux termes de (B.4.1)
sont « égaux » à r_V, alors que l'assertion vérifie un rapport de
(√5−1)/2 = 0.618. L'assertion était juste, le commentaire non.

**Trois tests ajoutés.**
- `t7` — loi de puissance `|γ − 1| ∝ β^{3/2}`, qui justifie l'inversion
  analytique du seuil Cassini.
- `t8` — le drapeau de validité bascule bien à ε = 1, et β = 10⁻¹¹ est rejeté.
- `t9` — `beta_max_cassini()` sature exactement la borne ; β = 1/M_Pl passe.

Le fichier renvoie désormais un code de sortie non nul en cas d'échec
(exploitable en CI). 9/9 passent.

## Exemple orbital

- Diagnostic d'énergie : l'ancienne version combinait l'ancienne distance et
  la nouvelle vitesse (décalage d'un demi-pas), gonflant la dérive affichée.
  Évaluation au même instant. Dérive mesurée : 4.5×10⁻⁸ sur une orbite —
  correct pour de l'Euler-Cromer à 1 jour de pas.
- L'orbite est circulaire (13.07 km/s au demi-grand axe vs 13.058 km/s de
  vitesse circulaire), pas celle de Jupiter à e = 0.0489. Le titre le dit.
- Option `--save` pour exécution sans affichage.
